# Build-Machine-Learning-Model-APIs-Udemy
For the documentation, visit the course on Udemy.

''' pip install -r requirements.txt
''' pip install -r RM/requirements.txt
''' pytest tests -W ignore::DeprecationWarning
